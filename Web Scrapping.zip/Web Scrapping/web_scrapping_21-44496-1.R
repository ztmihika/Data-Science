
#install.packages("rvest")
#install.packages("dplyr")
#install.packages("stringr")
#install.packages("httr")

library(rvest)
library(dplyr)
library(stringr)
library(httr)


link <- "https://www.goodreads.com/list/show/1.Best_Books_Ever"


page <- read_html(link)


book_titles <- page %>% html_nodes(".bookTitle span") %>% html_text()
print(book_titles)


author_names <- page %>% html_nodes(".authorName span") %>% html_text()
print(author_names)


ratings <- page %>% html_nodes(".minirating") %>% html_text()
print(ratings)


scores <- page %>% html_nodes(".uitext a:nth-child(1)") %>% html_text()
print(scores)


votes <- page %>% html_nodes(".greyText+ a") %>% html_text()
print(votes)



books_data <- data.frame(
  Title = book_titles,
  Author = author_names,
  Rating = ratings,
  Score = scores,
  Votes = votes,
  stringsAsFactors = FALSE
)


print(books_data)

write.csv(books_data, "goodreads_books_data.csv",row.names = FALSE)

print("Data has been saved to goodreads_books_data.csv")

